#!/usr/bin/env python3
"""KLYP Live: lightweight web UI for live chat-triggered clipping and crop selection."""
import os, sys, json, time, shutil, subprocess, threading, re, signal
from pathlib import Path
from fastapi import FastAPI, Form, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "clips"
CONFIG = ROOT / "klyp_layout.json"
LOG = ROOT / "klyp_live.log"
PREVIEW = ROOT / "klyp_preview.jpg"
OUT.mkdir(exist_ok=True)
app = FastAPI(title="KLYP Live")
app.mount("/clips", StaticFiles(directory=str(OUT)), name="clips")
proc = None
current_url = ""
proc_lock = threading.Lock()

@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "static" / "klyp_live.html").read_text(encoding="utf8")

@app.post("/api/start")
def start(url: str = Form(...)):
    global proc, current_url
    url = url.strip()
    if not ("youtube.com" in url or "youtu.be" in url or "twitch.tv" in url):
        raise HTTPException(400, "Paste a YouTube or Twitch livestream URL.")
    with proc_lock:
        if proc and proc.poll() is None:
            raise HTTPException(409, "A stream is already running. Stop it first.")
        if not shutil.which("streamlink"):
            raise HTTPException(400, "Streamlink is missing. Install the requirements first.")
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            raise HTTPException(400, "FFmpeg/FFprobe is missing. Install FFmpeg first.")
        current_url = url
        with open(LOG, "w", encoding="utf8") as log:
            proc = subprocess.Popen([sys.executable, str(ROOT / "liveclip.py"), url, "--layout", "custom", "--captions", "off", "--model", "small"],
                cwd=str(ROOT), stdout=log, stderr=subprocess.STDOUT)
    return {"ok": True, "message": "Clipping started. Preview refresh may take a few seconds."}


@app.post("/api/stop")
def stop():
    global proc
    with proc_lock:
        if proc and proc.poll() is None:
            proc.send_signal(signal.SIGINT)
            return {"ok": True, "message": "Stop requested; pending clips will finish."}
    return {"ok": True, "message": "No active process."}


@app.get("/api/status")
def status():
    alive = bool(proc and proc.poll() is None)
    tail = ""
    try:
        tail = LOG.read_text(errors="replace")[-5000:]
    except Exception: pass
    clips = sorted([p.name for p in OUT.glob("clip_*.mp4")], key=lambda p: (OUT / p).stat().st_mtime, reverse=True)
    return {"running": alive, "url": current_url, "log": tail, "clips": clips[:50]}


@app.post("/api/config")
def save_config(payload: dict):
    boxes = payload.get("boxes", {})
    face, game = boxes.get("face"), boxes.get("game")
    if not game:
        raise HTTPException(400, "Select a gameplay area first.")
    position = payload.get("face_position", "bottom-right")
    allowed_positions = {"bottom-right", "bottom-left", "top-right", "top-left", "bottom-center", "top-center"}
    if position not in allowed_positions: position = "bottom-right"
    cfg = {"boxes": {"face": face, "game": game}, "preview_size": [max(1, int(payload.get("width", 1280))), max(1, int(payload.get("height", 720)))], "face_pct": max(10, min(50, int(payload.get("face_pct", 35)))), "face_position": position}
    CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf8")
    return {"ok": True, "config": cfg}


@app.get("/api/preview")
def preview(url: str):
    url = url.strip()
    if not url: raise HTTPException(400, "Stream URL is required.")
    streamlink = shutil.which("streamlink")
    ffmpeg = shutil.which("ffmpeg")
    if not streamlink or not ffmpeg: raise HTTPException(400, "Install Streamlink and FFmpeg first.")
    try:
        # Resolve a playable media URL first instead of piping Streamlink bytes into
        # FFmpeg. This avoids FFmpeg seeing empty/partial pipe input on Colab.
        resolved = subprocess.run(
            [streamlink, "--stream-url", url, "720p,480p,best"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=25
        )
        media_url = resolved.stdout.strip().splitlines()[-1] if resolved.returncode == 0 and resolved.stdout.strip() else ""
        if not media_url:
            detail = resolved.stderr.strip()[-700:] or "Streamlink did not return a media URL. Check that the stream is live and publicly accessible."
            raise RuntimeError(detail)
        # Remove a stale frame so a previous preview can never be mistaken for a new one.
        try: PREVIEW.unlink()
        except FileNotFoundError: pass
        cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", media_url,
               "-vf", "scale='min(960,iw)':-2", "-frames:v", "1", "-q:v", "3", str(PREVIEW)]
        r = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=25)
        if r.returncode != 0 or not PREVIEW.exists() or PREVIEW.stat().st_size == 0:
            raise RuntimeError(r.stderr.decode(errors="replace")[-700:] or "FFmpeg could not decode a preview frame")
        from PIL import Image
        with Image.open(PREVIEW) as im:
            w, h = im.size
        return {"image": "/api/frame?t=" + str(time.time()), "width": w, "height": h}
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "Preview timed out. Try refreshing or check that the stream is live.")
    except Exception as e:
        raise HTTPException(400, "Preview failed: " + str(e))
@app.get("/api/frame")
def frame():
    if not PREVIEW.exists(): raise HTTPException(404, "Preview not loaded")
    return FileResponse(PREVIEW, media_type="image/jpeg")

@app.get("/api/config")
def get_config():
    try: return json.loads(CONFIG.read_text())
    except Exception: return {"boxes": {"face": None, "game": None}, "face_pct": 35}

if __name__ == "__main__":
    print("KLYP Live UI: http://127.0.0.1:7860")
    uvicorn.run(app, host="127.0.0.1", port=7860)

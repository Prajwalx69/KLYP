# KLYP Live — Catch the moment

A lightweight live-stream clipping tool. Paste a YouTube or Twitch live URL, load a frame preview, select the **facecam** and **gameplay** areas once, apply the layout, then start clipping. Every automatic chat-triggered clip uses your saved layout.


## Quick start

### Windows
1. Install **Python 3.10–3.12** and **FFmpeg** (FFmpeg must be available on PATH).
2. Double-click `Start KLYP Live.bat`. It creates a local virtual environment and installs the Python dependencies the first time.
3. Open the local address shown in the terminal: `http://127.0.0.1:7860`.


### macOS / Linux
1. Install Python 3.10–3.12, FFmpeg and Streamlink prerequisites (FFmpeg must be available on PATH).
2. From this folder, run:
   ```bash
   chmod +x 'Start KLYP Live.command'
   ./Start\ KLYP\ Live.command
   ```
3. Open `http://127.0.0.1:7860`.


## Workflow
1. Paste the live YouTube/Twitch URL.
2. **Load preview** to get a stream frame.
3. Drag a rectangle over the facecam area, then switch to **Gameplay area** and draw its rectangle.
4. Adjust the facecam share of the vertical output with the slider.
5. Click **Apply layout** to save your crop selection.
6. Click **Start live clipping**. Chat activity spikes trigger clips; clips are saved in `clips/`.
7. Stop with **Stop**. Pending clips are allowed to finish when possible.


## What it does
- Streamlink + FFmpeg live recording segments.
- YouTube/Twitch chat monitoring (the original LiveClip chat reader).
- Chat-spike automatic highlight triggers.
- Your saved facecam/gameplay crop boxes for vertical 9:16 clips.
- Clip list and browser playback/download.
- Layout selection saved in `klyp_layout.json`.


## Requirements
- Python 3.10–3.12
- FFmpeg and FFprobe available on PATH
- Streamlink
- Python dependencies from `requirements.txt`


## Notes
- This is a local app. It binds to `127.0.0.1`, not a public server.
- Preview frame extraction may take a few seconds and requires the stream to be live and accessible.
- Clips are triggered by chat spikes; it does not automatically understand every gameplay event.
- Captions are disabled in the simple KLYP Live interface to keep clipping lightweight. The existing LiveClip caption pipeline remains in `liveclip.py` and can be used directly with its command-line options.
- Only clip content when you have permission or the streamer allows it.

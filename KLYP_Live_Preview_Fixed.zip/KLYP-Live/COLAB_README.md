# KLYP Live — Colab edition

## Start on Android or desktop
1. Open `KLYP_Live_Colab.ipynb` in Google Colab.
2. Run cells from top to bottom.
3. When prompted, upload `KLYP_Live.zip` (the project archive).
4. Open the generated Colab proxy URL to access KLYP's web UI.
5. Keep the Colab runtime connected while live clipping. Download clips before ending the session.

Colab runtime may disconnect or reset, and the preview is a frame-based preview rather than a guaranteed full embedded live player.
